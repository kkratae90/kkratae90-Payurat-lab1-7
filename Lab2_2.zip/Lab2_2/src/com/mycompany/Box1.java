/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany;

/**
 *
 * @author K'Kratae
 */
public class Box1 {
    
    public double w,h,d;
    
    public double volume(){
        return w*h*d;
    }
    public double triangle(){
        return (0.5)*w*h;
    }
}

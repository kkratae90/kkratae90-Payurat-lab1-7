/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany;

/**
 *
 * @author K'Kratae
 */
public class Box2 {
    public int x,z;
    
    public void multiply(){
        for(int i=1; i < 12;i++){
            z = x*1;
            System.out.println(x+"*"+i+"="+z);
        }
    }
    
}

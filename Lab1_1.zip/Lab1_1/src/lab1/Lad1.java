/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

/**
 *
 * @author K'Kratae
 */
public class Lad1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("welcome");
        System.out.println("พายุรัตน์ คชริทร์");
        System.out.println("รหัส 30332");
        System.out.println("อายุ 21 ปี");
        System.out.println("เบอร์ 0967576122");
        System.out.println("สาขา คอมพิวเตอร์โปรแกรมเมอร์");
    }
    public void abc(){//Method
        System.out.println("Siam Dhurakit Technoiogy");
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author K'Kratae
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int age = 21;
        double gpa=3.59;
        String name="พายุรัตน์ คชรินทร์";
        char gender= 'M';
        System.out.println("This is Programming!!");
        System.out.println("ชื่อ"+ name + "\nเพศ" +gender);
        System.out.println("อายุ"+ age + "\n เกรดเฉลี่ย" +gpa);
    }
    
}

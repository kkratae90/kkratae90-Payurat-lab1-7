package lab3;

public class Calculator {
    public double a, b, c; //modifier ,Variable
    
    
    public double Squire(double w, double h){
        return w*h;
    }
    
    public void Multiply(){
        b=5;
        for(a=1; a<12; a++){
            c= b*a;
            System.out.println(b+ "*" +a +"="+c);
        }
    }
}

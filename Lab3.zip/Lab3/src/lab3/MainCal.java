package lab3;

public class MainCal {

   
    public static void main(String[] args) {
        Calculator c = new Calculator();
        c.a = 5;
        c.b = 10;
        
        System.out.println("พื้นที่สี่เหลี่ยม" + c.Squire(c.a , c.b));
        
        c.Multiply();
    }
    
}
